package Admin;

import java.awt.Component;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.JTextPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
@SuppressWarnings("unused")

public class WorkerPFMain extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField tfUser;
	private JTextField tfMail;
	private JTextField tfPass;
	private JTextField tfPhone;
	private JTable tableUsers;
	private DefaultTableModel tableModel;
	private JComboBox<String> comboBox;
	private String username;
	private String officerUsername;
	private boolean addAdministratorDataBack = false;
	private String mainFilePath;
	private String tempFilePath;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					WorkerPFMain frame = new WorkerPFMain("","");
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public WorkerPFMain(String username,String officerUsername) {
		this.officerUsername = officerUsername;
		this.username = username;
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 840, 476);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Worker Profile");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Imprint MT Shadow", Font.BOLD, 30));
		lblNewLabel.setBounds(246, 11, 317, 80);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Username");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_1.setBounds(25, 77, 66, 26);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Mail Address");
		lblNewLabel_2.setBounds(25, 197, 66, 26);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("User Role");
		lblNewLabel_3.setBounds(25, 121, 66, 19);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Password");
		lblNewLabel_4.setBounds(25, 161, 66, 19);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("PhoneNumber");
		lblNewLabel_5.setBounds(25, 241, 82, 19);
		contentPane.add(lblNewLabel_5);
		
		tfUser = new JTextField();
		tfUser.setBounds(130, 75, 150, 30);
		contentPane.add(tfUser);
		tfUser.setColumns(10);
		
		tfMail = new JTextField();
		tfMail.setBounds(130, 195, 150, 30);
		contentPane.add(tfMail);
		tfMail.setColumns(10);
		
		tfPass = new JTextField();
		tfPass.setBounds(130, 155, 150, 30);
		contentPane.add(tfPass);
		tfPass.setColumns(10);
		
		tfPhone = new JTextField();
		tfPhone.setBounds(130, 235, 150, 30);
		contentPane.add(tfPhone);
		tfPhone.setColumns(10);
		
		tableUsers = new JTable();
        JScrollPane scrollPane = new JScrollPane(tableUsers);
        scrollPane.setBounds(299, 82, 515, 318);
        contentPane.add(scrollPane);

        tableModel = new DefaultTableModel();
        tableModel.addColumn("Username");
        tableModel.addColumn("User Role");
        tableModel.addColumn("Password");
        tableModel.addColumn("Mail Address");
        tableModel.addColumn("PhoneNumber");
        tableUsers.setModel(tableModel);
         
        tableUsers.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent event) {
                if (!event.getValueIsAdjusting()) {
                    int selectedRow = tableUsers.getSelectedRow();
                    if (selectedRow != -1) {
                        Object usernameObj = tableModel.getValueAt(selectedRow, 0);
                        Object userRoleObj = tableModel.getValueAt(selectedRow, 1);
                        Object passwordObj = tableModel.getValueAt(selectedRow, 2);
                        Object mailAddressObj = tableModel.getValueAt(selectedRow, 3);
                        Object phoneNumberObj = tableModel.getValueAt(selectedRow, 4);

                        String username = (usernameObj != null) ? usernameObj.toString() : "";
                        String userRole = (userRoleObj != null) ? userRoleObj.toString() : "";
                        String password = (passwordObj != null) ? passwordObj.toString() : "";
                        String mailAddress = (mailAddressObj != null) ? mailAddressObj.toString() : "";
                        String phoneNumber = (phoneNumberObj != null) ? phoneNumberObj.toString() : "";

                        tfUser.setText(username);
                        tfMail.setText(mailAddress);
                        tfPass.setText(password);
                        tfPhone.setText(phoneNumber);

                        comboBox.setSelectedItem(userRole);
                    }
                }
            }
        });
		
        JButton btnNewButton = new JButton("Modified");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	int selectedRow = tableUsers.getSelectedRow();
            if (selectedRow != -1) {
                String username = tfUser.getText();
                String userRole = comboBox.getSelectedItem().toString();
                String password = tfPass.getText();
                String mailAddress = tfMail.getText();
                String phoneNumber = tfPhone.getText();

                // Update the data in the table model
                tableModel.setValueAt(username, selectedRow, 0);
                tableModel.setValueAt(userRole, selectedRow, 1);
                tableModel.setValueAt(password, selectedRow, 2);
                tableModel.setValueAt(mailAddress, selectedRow, 3);
                tableModel.setValueAt(phoneNumber, selectedRow, 4);

                // Save the modified data back to the file
                saveDataToFile();
            }
        }
    });
        String[] colum = {"","Officer","Sales Person"};
        comboBox = new JComboBox<>(colum);
        comboBox.setEditable(true);
        comboBox.setToolTipText("");
        comboBox.setBounds(130, 115, 150, 31);
        contentPane.add(comboBox);
       
    
        btnNewButton.setBounds(162, 294, 89, 23);
        contentPane.add(btnNewButton);
        
        JButton btnNewButton_1 = new JButton("Quit");
        btnNewButton_1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		AdminMain AdminMain = new AdminMain(username);
        		AdminMain.setVisible(true);
        		dispose();
        	}
        });
        btnNewButton_1.setBounds(725, 46, 89, 23);
        contentPane.add(btnNewButton_1);
        
     
        loadDataFromFile();
        String currentDirectory = System.getProperty("user.dir");
        mainFilePath = currentDirectory + "/users.txt";
        tempFilePath = currentDirectory + "/temp_users.txt";
 
	}
	    
	
	

	private void loadDataFromFile() {
	    String currentDirectory = System.getProperty("user.dir");
	    String filePath = currentDirectory + "/users.txt";

	    // Clear the table model
	    tableModel.setRowCount(0);

	    try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
	        String line;
	        while ((line = reader.readLine()) != null) {
	            String[] userData = line.split(" \\| ");
	            boolean isAdmin = false;
	            for (String data : userData) {
	                if (data.contains("User Role: Administrator")) {
	                    isAdmin = true;
	                    break;
	                }
	            }
	            if (!isAdmin) {
	                for (int i = 0; i < userData.length; i++) {
	                    String[] fieldData = userData[i].split(": ");
	                    if (fieldData.length == 2) {
	                        userData[i] = fieldData[1];
	                    } else {
	                        userData[i] = "";
	                    }
	                }

	                // Add user data to the table model
	                tableModel.addRow(userData);
	            }
	        }
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}
	   

	private void updateTextFields(int selectedRow) {
	        Object usernameObj = tableModel.getValueAt(selectedRow, 0);
	        Object mailAddressObj = tableModel.getValueAt(selectedRow, 1);
	        Object passwordObj = tableModel.getValueAt(selectedRow, 3);
	        Object phoneNumberObj = tableModel.getValueAt(selectedRow, 4);

	        String username = (usernameObj != null) ? usernameObj.toString() : "";
	        String mailAddress = (mailAddressObj != null) ? mailAddressObj.toString() : "";
	        String password = (passwordObj != null) ? passwordObj.toString() : "";
	        String phoneNumber = (phoneNumberObj != null) ? phoneNumberObj.toString() : "";

	        tfUser.setText(username);
	        tfMail.setText(mailAddress);
	        tfPass.setText(password);
	        tfPhone.setText(phoneNumber);
	    }

	    private void updateComboBox(int selectedRow) {
	        Object userRoleObj = tableModel.getValueAt(selectedRow, 2);
	        if (userRoleObj != null) {
	            String selectedUserRole = userRoleObj.toString().trim();
	            comboBox.setSelectedItem(selectedUserRole);
	        }
	    }
	    private void saveDataToFile() {
	        int selectedRow = tableUsers.getSelectedRow();
	        if (selectedRow == -1) {
	            JOptionPane.showMessageDialog(contentPane, "Please select a row to modify.", "Error", JOptionPane.ERROR_MESSAGE);
	            return;
	        }

	        // Construct the modified data string in the specified format
	        String modifiedData = getFormattedRowData();

	        // Read the existing data from the file
	        List<String> fileData = new ArrayList<>();
	        try (BufferedReader reader = new BufferedReader(new FileReader(mainFilePath))) {
	            String line;
	            while ((line = reader.readLine()) != null) {
	                fileData.add(line);
	            }
	        } catch (IOException e) {
	            e.printStackTrace();
	            JOptionPane.showMessageDialog(contentPane, "Error reading data from file.", "Error", JOptionPane.ERROR_MESSAGE);
	            return;
	        }

	        // Update the selected row in the file data list
	        fileData.set(selectedRow, modifiedData);

	        // Write the modified data back to the original file
	        try (BufferedWriter writer = new BufferedWriter(new FileWriter(mainFilePath))) {
	            for (String line : fileData) {
	                writer.write(line);
	                writer.newLine();
	            }
	            JOptionPane.showMessageDialog(contentPane, "Data saved successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
	        } catch (IOException e) {
	            e.printStackTrace();
	            JOptionPane.showMessageDialog(contentPane, "Error saving data to file.", "Error", JOptionPane.ERROR_MESSAGE);
	        }
	    }

	    private String getFormattedRowData() {
	        StringBuilder rowData = new StringBuilder();
	        rowData.append("Username: ").append(tfUser.getText()).append(" | ");
	        rowData.append("User Role: ").append(comboBox.getSelectedItem().toString()).append(" | ");
	        rowData.append("Password: ").append(tfPass.getText()).append(" | ");
	        rowData.append("Mail Address: ").append(tfMail.getText()).append(" | ");
	        rowData.append("Phone Number: ").append(tfPhone.getText());
	        return rowData.toString();
	    }
}