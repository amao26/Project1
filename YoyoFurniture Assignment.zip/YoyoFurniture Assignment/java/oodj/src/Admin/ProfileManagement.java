package Admin;


import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Officer.UserProfileManager;
import Officer.officerMain;
import Saleperson.SalePersonMain;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;

@SuppressWarnings("unused")
public class ProfileManagement extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField tfusername;
	private JTextField tfMailAddress;
	private JTextField tfpassword;
	private JTextField tfphonenumber;
	private JComboBox<String> comboBox;
	private String officerUsername;
	@SuppressWarnings("unused")
	private officerMain officerMainPage;
	@SuppressWarnings("unused")
	private String previousPage;
	private String username;
	private JLabel usernameLabel; 
	private String originalUsername;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ProfileManagement frame = new ProfileManagement("","");
					frame.setVisible(true);
			 } catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @wbp.parser.constructor
	 */
	public ProfileManagement(String username, String previousPage ) {
		
		this.username = username;
		this.originalUsername = username;
		this.previousPage = previousPage;
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 675, 470);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Profile Management");
		lblNewLabel.setFont(new Font("Imprint MT Shadow", Font.BOLD, 30));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(102, 11, 448, 36);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Username");
		lblNewLabel_1.setBounds(57, 57, 60, 25);
		contentPane.add(lblNewLabel_1);
		
		tfusername = new JTextField();
		tfusername.setBounds(221, 55, 149, 20);
		contentPane.add(tfusername);
		tfusername.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Mail Address");
		lblNewLabel_2.setBounds(57, 99, 60, 14);
		contentPane.add(lblNewLabel_2);
		
		tfMailAddress = new JTextField();
		tfMailAddress.setBounds(221, 96, 149, 20);
		contentPane.add(tfMailAddress);
		tfMailAddress.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("User Role");
		lblNewLabel_3.setBounds(57, 146, 60, 14);
		contentPane.add(lblNewLabel_3);
		
		String[] colum = {"","Officer","Administrator","Sales Person"};
	    comboBox = new JComboBox<>(colum);
		comboBox.setBounds(221, 142, 149, 22);
		contentPane.add(comboBox);
		
		JLabel lblNewLabel_4 = new JLabel("Password");
		lblNewLabel_4.setBounds(57, 186, 60, 14);
		contentPane.add(lblNewLabel_4);
		
		tfpassword = new JTextField();
		tfpassword.setBounds(221, 183, 149, 20);
		contentPane.add(tfpassword);
		tfpassword.setColumns(10);
		
		this.usernameLabel = new JLabel();
		this.usernameLabel.setText("Default Text");
		this.usernameLabel.setFont(new Font("Arial", Font.PLAIN, 12));
		
		JLabel lblNewLabel_5 = new JLabel("PhoneNumber");
		lblNewLabel_5.setBounds(57, 231, 78, 20);
		contentPane.add(lblNewLabel_5);
		
		tfphonenumber = new JTextField();
		tfphonenumber.setBounds(221, 231, 149, 20);
		contentPane.add(tfphonenumber);
		tfphonenumber.setColumns(10);
	
		
		JButton btnNewButton_1 = new JButton("Cancel");
		btnNewButton_1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					 if (previousPage != null) {
			                switch (previousPage) {
			                    case "admin":
			                        // Redirect to admin page
			                        AdminMain frame = new AdminMain(originalUsername); // Use originalUsername
			                        frame.setVisible(true);
			                        break;
			                    case "officer":
			                        // Redirect to officer page
			                        officerMain officerMain = new officerMain(originalUsername); // Use originalUsername
			                        officerMain.setVisible(true);
			                        break;
			                    case "salesperson":
			                        // Redirect to salesperson page
			                        SalePersonMain salePersonMain = new SalePersonMain(originalUsername, "");
			                        salePersonMain.setVisible(true);
			                        break;
			                    default:
			                        // Default redirect to officer page
			                        officerMain officerMainPage = new officerMain("");
			                        officerMainPage.setVisible(true);
			                        break;
			                }
			            }
			            dispose();
			        }
			    });
		btnNewButton_1.setBounds(339, 295, 89, 23);
		contentPane.add(btnNewButton_1);

        JButton btnSave = new JButton("Save");
        btnSave.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
                // Get the username from tfusername text field
                String username = tfusername.getText();
                
                // Print out the value for verification
                System.out.println("Username from text field: " + username);
                
                // Rest of your code
                String mailbox = tfMailAddress.getText();
                String userRole = comboBox.getSelectedItem().toString();
                String password = tfpassword.getText();
                String phoneNumber = tfphonenumber.getText();

                // Call the method to save profile information 
                saveProfileInformation(username, mailbox, userRole, password, phoneNumber);
            }
        });;
            	
            
        btnSave.setBounds(199, 295, 89, 23);
        contentPane.add(btnSave);
        
    	
		displayProfileInformation();
		
 
    }
	
	 private void displayProfileInformation() {
		 String currentDirectory = System.getProperty("user.dir");
		 String filePath = currentDirectory + "/users.txt";
		    String line;
		    try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
		        while ((line = reader.readLine()) != null) {
		            if (line.contains("Username: " + username)) {
		                String[] userInfo = line.split("\\|");
		                for (String info : userInfo) {
		                    if (info.contains("Username: ")) {
		                        tfusername.setText(info.trim().replace("Username: ", ""));
		                    } else if (info.contains("Mail Address: ")) {
		                        tfMailAddress.setText(info.trim().replace("Mail Address: ", ""));
		                    } else if (info.contains("User Role: ")) {
		                        comboBox.setSelectedItem(info.trim().replace("User Role: ", ""));
		                    } else if (info.contains("Password: ")) {
		                        tfpassword.setText(info.trim().replace("Password: ", ""));
		                    } else if (info.contains("Phone Number: ")) {
		                        tfphonenumber.setText(info.trim().replace("Phone Number: ", ""));
		                    }
		                }
		                break;
		            }
		        }
		    } catch (IOException e) {
		        e.printStackTrace();
		    }
	    }
	 private void saveProfileInformation(String username, String mailAddress, String userRole, String password, String phoneNumber) {
		    try {
		        String currentDirectory = System.getProperty("user.dir");
		        String filePath = currentDirectory + "/users.txt";

		        // Print out the username for verification
		        System.out.println("Username to save: " + username);

		        // Read the existing contents of the file
		        List<String> lines = Files.readAllLines(Paths.get(filePath));

		        // Update the profile information in the lines list
		        for (int i = 0; i < lines.size(); i++) {
		            String line = lines.get(i);
		            if (line.contains("Username: " + this.username)) {
		                // Split the line into its parts
		                String[] parts = line.split("\\|");
		                for (int j = 0; j < parts.length; j++) {
		                    if (parts[j].contains("Username: ")) {
		                        parts[j] = "Username: " + username; // Update the username
		                    } else if (parts[j].contains("User Role:")) {
		                        parts[j] = "User Role: " + userRole;
		                    } else if (parts[j].contains("Password:")) {
		                        parts[j] = "Password: " + password;
		                    } else if (parts[j].contains("Mail Address:")) {
		                        parts[j] = "Mail Address: " + mailAddress;
		                    } else if (parts[j].contains("Phone Number:")) {
		                        parts[j] = "Phone Number: " + phoneNumber;
		                    }
		                }
		                // Reconstruct the updated line
		                StringBuilder updatedLineBuilder = new StringBuilder();
		                for (String part : parts) {
		                    updatedLineBuilder.append(part.trim()).append(" | ");
		                }
		                // Remove the last "|" and update the line
		                String updatedLine = updatedLineBuilder.toString().replaceAll("\\| $", "");
		                lines.set(i, updatedLine);
		                break;
		            }
		        }

		        // Write the updated lines back to the file
		        Files.write(Paths.get(filePath), lines);

		        // Notify user about successful profile update
		        JOptionPane.showMessageDialog(null, "Profile updated successfully");

		        // Send username credential to UserProfileManager in Officer package
		        UserProfileManager userProfileManager = new UserProfileManager(username, usernameLabel);
		        userProfileManager.retrieveUserProfile();
		    } catch (IOException e) {
		        e.printStackTrace();
		        JOptionPane.showMessageDialog(null, "Failed to update profile");
		    }
		}
	 

}

