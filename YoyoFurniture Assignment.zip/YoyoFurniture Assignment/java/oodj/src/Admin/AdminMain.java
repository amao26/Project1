package Admin;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Login.LoginScreen;
import Officer.UserProfileManager;

import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JSeparator;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
public class AdminMain extends JFrame {
	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JLabel usernameLabel;
	private String username;
	@SuppressWarnings("unused")
	private String userRole;
	@SuppressWarnings("unused")
	private String officerUsername;

	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
	
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminMain frame = new AdminMain("");
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AdminMain(String username) {
		this.username = username;
		this.officerUsername = username;
		this.userRole = "admin";
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 675, 470);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Admin Page");
		lblNewLabel.setFont(new Font("Imprint MT Shadow", Font.BOLD, 30));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(367, 40, 198, 54);
		contentPane.add(lblNewLabel);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(55, 83, 552, 2);
		contentPane.add(separator);
		
		JButton btnNewButton = new JButton("Log Out");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				LoginScreen loginScreen = new LoginScreen();
	            loginScreen.setVisible(true);
	            dispose();
			}
		});
		btnNewButton.setBounds(54, 62, 89, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Manage Profile");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ProfileManagement PM1 = new ProfileManagement(username,"admin");
		        PM1.setVisible(true);
		        dispose();
			}
		});
		btnNewButton_1.setBounds(55, 126, 130, 55);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Worker Profile");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				WorkerPFMain  WorkerPFMain= new WorkerPFMain(username,"");
				WorkerPFMain.setVisible(true);
				dispose();			
			}
		});
		btnNewButton_2.setBounds(283, 126, 130, 55);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Generate Report");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GenerateReportMain GenerateReportMain = new GenerateReportMain(username,"admin",userRole);
				GenerateReportMain.setVisible(true);
				dispose();
			}
		});
		btnNewButton_3.setBounds(435, 126, 130, 55);
		contentPane.add(btnNewButton_3);
		
		usernameLabel = new JLabel();
		usernameLabel.setHorizontalAlignment(SwingConstants.CENTER);
		usernameLabel.setBounds(248, 62, 109, 23);
		contentPane.add(usernameLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Welcome User");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(165, 62, 95, 23);
		contentPane.add(lblNewLabel_1);
		
		retrieveUserProfile();
		

	}
	void retrieveUserProfile() {
	    UserProfileManager userProfileManager = new UserProfileManager(username, usernameLabel);
	    userProfileManager.retrieveUserProfile();
	}
	
}




