package Admin;

import java.awt.EventQueue;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Officer.ApprovedSRMain;
import Officer.ClosedRPMain;
import Officer.UserProfileManager;
import Officer.WorkDoneRPMain;
import Officer.officerMain;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.awt.event.ActionEvent;

public class GenerateReportMain extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	@SuppressWarnings("unused")
	private String officerUsername;
	private JLabel usernameLabel;
	@SuppressWarnings("unused")
	private String userRole;
	@SuppressWarnings("unused")
	private String username;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GenerateReportMain frame = new GenerateReportMain("", "","");
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});


	}
	

	/**
	 * Create the frame.
	 */
	
	public GenerateReportMain(String username, String officerUsername, String userRole) {	
		this.officerUsername = officerUsername;
		this.username = username;
		this.userRole = userRole;
		

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 675, 350);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Generate Report");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Imprint MT Shadow", Font.BOLD, 30));
		lblNewLabel.setBounds(210, 23, 251, 54);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Approved Sale Report");
		btnNewButton.addActionListener(new ActionListener() {
	
			public void actionPerformed(ActionEvent e) {
				System.out.println("Username before passing to ApprovedSRMain: " + username);
				ApprovedSRMain ApprovedSRMain = new ApprovedSRMain(username);
				ApprovedSRMain.setVisible(true);
				dispose();
			}
		});
		btnNewButton.setBounds(253, 184, 152, 43);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Work done Report");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				WorkDoneRPMain WorkDoneRPMain = new WorkDoneRPMain(username);
				WorkDoneRPMain.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setBounds(404, 184, 152, 43);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Closed sale Report");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ClosedRPMain ClosedRPMain = new ClosedRPMain(username);
				ClosedRPMain.setVisible(true);
				dispose();	
			}
		});
		btnNewButton_2.setBounds(103, 184, 152, 43);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Quit");
		btnNewButton_3.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		    	String currentDirectory = System.getProperty("user.dir");
			    String filePath = currentDirectory + "/users.txt";
		        String username = usernameLabel.getText();
		        String role = getUserRoleFromFile(username, filePath);
		        
		        if (role.matches("(?i).*\\bAdministrator\\b.*")) {
		            AdminMain AdminMain = new AdminMain(username);
		            AdminMain.setVisible(true);
		        } else if (role.matches("(?i).*\\bofficer\\b.*")) {
		            officerMain officerMain = new officerMain(username);
		            officerMain.setVisible(true);
		        } else {
		            JOptionPane.showMessageDialog(null, "User role not found", "Error", JOptionPane.ERROR_MESSAGE);
		        }
		        
		        dispose(); // Close the current window
		    }
		});
		btnNewButton_3.setBounds(512, 45, 89, 23);
		contentPane.add(btnNewButton_3);
		
		usernameLabel = new JLabel();
        usernameLabel.setHorizontalAlignment(SwingConstants.CENTER);
		usernameLabel.setBounds(69, 45, 140, 23);
		contentPane.add(usernameLabel);
		
		retrieveUserProfile(username);
	}
    
	 void retrieveUserProfile(String username) {
	        String currentDirectory = System.getProperty("user.dir");
	        String filePath = currentDirectory + "/users.txt";
	        UserProfileManager userProfileManager = new UserProfileManager(username, usernameLabel); // Pass only username
	        userProfileManager.retrieveUserProfile();
	        System.out.println("Username in retrieveUserProfile: " + username);
	    usernameLabel.setText(username); // Set the value of the usernameLabel
	    @SuppressWarnings("unused")
	    String role = getUserRoleFromFile(username, filePath);
	}
	String getUserRoleFromFile(String username, String filePath) {
		String currentDirectory = System.getProperty("user.dir");
	    String filePath1 = currentDirectory + "/users.txt";
		 try (BufferedReader br = new BufferedReader(new FileReader(filePath1))) {
		        String line;
		        while ((line = br.readLine()) != null) {
		            if (line.contains("Username: " + username)) {
		                String[] parts = line.split("\\|");
		                for (String part : parts) {
		                    if (part.contains("User Role:")) {
		                        String[] roleParts = part.trim().split(":");
		                        if (roleParts.length == 2) {

		                            return roleParts[1].trim();
		                        }
		                    }
		                }
		            }
		        }
		    } catch (IOException e) {
		        e.printStackTrace();
		    }
		    return "";
		}
}

	

