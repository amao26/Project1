package Login;


import java.awt.EventQueue;
import java.sql.ResultSet;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Admin.AdminMain;
import Officer.officerMain;
import Saleperson.SalePersonMain;

import java.awt.Color;
import javax.swing.JButton;
import java.awt.SystemColor;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.awt.event.ActionEvent;
import javax.swing.UIManager;
import javax.swing.JTextField;
import javax.swing.JSeparator;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.ImageIcon;
import javax.swing.JTable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Arrays;

import javax.swing.JList;
import javax.swing.JScrollBar;
import javax.swing.JComboBox;

@SuppressWarnings("unused")
public class LoginScreen extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField user;
	private JPasswordField pass;
	private JTable table;
	private JComboBox<String> comboBox;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginScreen frame = new LoginScreen();
					frame.setUndecorated(isDefaultLookAndFeelDecorated());
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public LoginScreen() {	
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 675, 470);
		contentPane = new JPanel();
		contentPane.setForeground(Color.WHITE);
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 0, 128));
		panel.setBounds(10, 11, 309, 405);
		contentPane.add(panel);
		panel.setLayout(null);
		
		table = new JTable();
		table.setBounds(154, 1562, 0, 0);
		panel.add(table);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(0, 65, 299, 219);
		panel.add(lblNewLabel_1);
		lblNewLabel_1.setIcon(new ImageIcon(LoginScreen.class.getResource("/images/th (1).jpg")));
		
		JLabel lblNewLabel_2 = new JLabel("The Perfect Choice\r\n");
		lblNewLabel_2.setForeground(new Color(240, 248, 255));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setBounds(73, 281, 158, 40);
		panel.add(lblNewLabel_2);
		
		JButton btnNewButton = new JButton("Log In");
		btnNewButton.setForeground(new Color(0, 0, 0));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { String username = user.getText();
	        String password = new String(pass.getPassword());
	        String role = (String) comboBox.getSelectedItem();

	        if (validateUser(username, password, role)) {
	            // Successful login
	            JOptionPane.showMessageDialog(null, "Login successful!");

	            // Navigate to different pages based on the user's role
	            if (role.equals("Officer")) {
	                // Code to navigate to Officer page
	            	officerMain officerMain = new officerMain(username);
	            	officerMain.setVisible(true);
	                dispose();
	            } else if (role.equals("Administrator")) {
	                // Code to navigate to Admin page
	            	AdminMain AdminMain = new AdminMain(username);
	            	AdminMain.setVisible(true);
	                dispose();
	            } else if (role.equals("Sales Person")) {
	                // Code to navigate to Sales Person page
	            	SalePersonMain SalePersonMain = new SalePersonMain(username,"");
	            	SalePersonMain.setVisible(true);
	                dispose();
	            }
	        } else {
	            // Invalid credentials
	            JOptionPane.showMessageDialog(null, "Invalid username, password, or role. Please try again.");
	        }
	    }
	});
		btnNewButton.setBackground(new Color(241,57,83));
		btnNewButton.setBounds(399, 306, 105, 23);
		contentPane.add(btnNewButton);
		
		user = new JTextField();
		user.setBounds(339, 104, 242, 23);
		contentPane.add(user);
		user.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("UserName");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(329, 70, 60, 23);
		contentPane.add(lblNewLabel);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setHorizontalAlignment(SwingConstants.CENTER);
		lblPassword.setBounds(329, 210, 60, 23);
		contentPane.add(lblPassword);
		
		pass = new JPasswordField();
		pass.setBounds(339, 244, 242, 23);
		contentPane.add(pass);
		
		String[] colum = {"","Officer","Administrator","Sales Person"};
		comboBox = new JComboBox<>(colum);
		comboBox.setBounds(339, 163, 242, 22);
		contentPane.add(comboBox);
		
		JLabel lblNewLabel_4 = new JLabel("User Role");
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setBounds(329, 138, 60, 14);
		contentPane.add(lblNewLabel_4);
		
		JButton SignupB1 = new JButton("Sign up");
		SignupB1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RegisterUser RG1 = new RegisterUser();
		        RG1.setVisible(true);
		        
		        dispose();
			}
		});	
		SignupB1.setBounds(409, 363, 89, 23);
		contentPane.add(SignupB1);
	}
		private boolean validateUser(String username, String password, String role) {
		    try (BufferedReader reader = new BufferedReader(new FileReader("users.txt"))) {
		        String line;
		        while ((line = reader.readLine()) != null) {
		            if (line.contains("Username: " + username) && line.contains("Password: " + password) && line.contains("User Role: " + role)) {
		                System.out.println("Successfully read from the file."); // Print a success message
		                return true;
		            }
		        }
		    } catch (IOException e) {
		        e.printStackTrace();
		    }
		    System.out.println("Failed to read from the file."); // Print a failure message
		    return false;
		}

}

