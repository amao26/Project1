package Login;

import java.awt.EventQueue;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class RegisterUser extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JComboBox<String> comboBox;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RegisterUser frame = new RegisterUser();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	private void registerUser() {
	    String username = textField.getText();
	    String userRole = comboBox.getSelectedItem().toString();
	    String password = textField_2.getText();
	    String email = textField_1.getText();
	    String phoneNumber = textField_3.getText();
	    
	    String userInfo = "Username: " + username + " | "
	            + "User Role: " + userRole + " | "
	            + "Password: " + password + " | "
	            + "Mail Address: " + email + " | "
	            + "Phone Number: " + phoneNumber;

	    // Get the current working directory
	    String currentDirectory = System.getProperty("user.dir");
	    String filePath = currentDirectory + "/users.txt";

	    try {
	        // Check for duplicate username
	        if (checkForDuplicateUsername(filePath, username)) {
	            // Display warning message for duplicate username
	            JOptionPane.showMessageDialog(this, "Username already exists. Please choose a different username.", "Warning", JOptionPane.WARNING_MESSAGE);
	            return; // Exit method if duplicate username found
	        }

	        // Create a FileWriter object with the file path
	        FileWriter fileWriter = new FileWriter(filePath, true);

	        // Write the user information to the file
	        fileWriter.write(userInfo);
	        fileWriter.write("\n");

	        // Close the FileWriter
	        fileWriter.close();

	        JOptionPane.showMessageDialog(this, "User information saved to file successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}
	
	public RegisterUser() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 675, 470);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Username");
		lblNewLabel_1.setBounds(33, 47, 70, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("User Role");
		lblNewLabel_2.setBounds(33, 161, 46, 14);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Password");
		lblNewLabel_3.setBounds(33, 218, 70, 14);
		contentPane.add(lblNewLabel_3);
		
		textField = new JTextField();
		textField.setBounds(117, 44, 220, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(117, 101, 220, 20);
		contentPane.add(textField_1);
		
		String[] colum1 = {"","Officer","Administrator","Sales Person"};
		comboBox = new JComboBox<>(colum1);
		comboBox.setBounds(117, 157, 220, 22);
		contentPane.add(comboBox);
		
		textField_2 = new JTextField();
		textField_2.setBounds(117, 215, 220, 20);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		JButton btnNewButton = new JButton("Save");
		btnNewButton.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        registerUser();
		    }
		});
		btnNewButton.setBounds(117, 316, 89, 23);
		contentPane.add(btnNewButton);
		
		textField_3 = new JTextField();
		textField_3.setBounds(117, 272, 220, 20);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Mail Address");
		lblNewLabel.setBounds(33, 104, 46, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_4 = new JLabel("PhoneNumber");
		lblNewLabel_4.setBounds(33, 275, 81, 14);
		contentPane.add(lblNewLabel_4);
		
		JButton btnNewButton_1 = new JButton("Complete");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
                LoginScreen loginScreen = new LoginScreen();
                loginScreen.setVisible(true);			
				}
		});
		btnNewButton_1.setBounds(234, 316, 89, 23);
		contentPane.add(btnNewButton_1);
	
	}

	private boolean checkForDuplicateUsername(String filepath, String username) throws IOException {
	    try (BufferedReader reader = new BufferedReader(new FileReader(filepath))) {
	        String line;
	        while ((line = reader.readLine()) != null) {
	            if (line.startsWith("Username: " + username)) {
	                return true;
	            }
	        }
	    }
	    return false;
	}
}
