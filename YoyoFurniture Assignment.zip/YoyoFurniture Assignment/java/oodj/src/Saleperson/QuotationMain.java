package Saleperson;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTable;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.awt.event.ActionEvent;

public class QuotationMain extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField TextID;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JButton btnNewButton_1;
	private JLabel lblNewLabel_5;
	private JTextField textField_5;
	private JButton btnNewButton_2;
	private JButton btnNewButton_3;
	
	private DefaultTableModel tableModel;
	private JTable tablecontent;
	private JButton btnNewButton_5;
	@SuppressWarnings("unused")
	private String officerUsername;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					QuotationMain frame = new QuotationMain("");
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public QuotationMain(String username) {
		this.officerUsername = username;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 650);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("OrderID");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(23, 46, 66, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Item Name");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(22, 94, 67, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Quantity");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setBounds(23, 144, 66, 14);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Price");
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setBounds(23, 186, 66, 19);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Sign By");
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setBounds(23, 241, 66, 14);
		contentPane.add(lblNewLabel_4);
		
		TextID = new JTextField();
		TextID.setBounds(99, 43, 162, 19);
		contentPane.add(TextID);
		TextID.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(99, 91, 162, 19);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(99, 141, 162, 19);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(99, 185, 162, 20);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setBounds(99, 238, 162, 20);
		contentPane.add(textField_4);
		textField_4.setColumns(10);
				
		 JButton btnNewButton = new JButton("Create");
	        btnNewButton.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	                // Get the input values from the text fields
	                String orderID = TextID.getText();
	                String itemName = textField_1.getText();
	                String quantity = textField_2.getText();
	                String price = textField_3.getText();
	                String holdBy = textField_4.getText();
	                
	                // Check if any of the text fields are empty
	                if (orderID.isEmpty() || itemName.isEmpty() || quantity.isEmpty() || price.isEmpty() || holdBy.isEmpty()) {
	                    // Display a warning message indicating that all fields must be filled
	                    JOptionPane.showMessageDialog(contentPane, "Please fill in all fields.", "Empty Fields", JOptionPane.WARNING_MESSAGE);
	                } else {
	                    // Check if the orderID already exists in the table
	                    boolean isDuplicate = false;
	                    for (int i = 0; i < tableModel.getRowCount(); i++) {
	                        String existingOrderID = tableModel.getValueAt(i, 0).toString();
	                        if (orderID.equals(existingOrderID)) {
	                            isDuplicate = true;
	                            break;
	                        }
	                    }
	                    
	                    if (isDuplicate) {
	                        // Display a warning message indicating that the orderID already exists
	                        JOptionPane.showMessageDialog(contentPane, "OrderID already exists. Please enter a unique OrderID.", "Duplicate OrderID", JOptionPane.WARNING_MESSAGE);
	                    } else {
	                        // Add the data to the table model
	                        tableModel.addRow(new Object[]{orderID, itemName, quantity, price, holdBy});
	                        
	                        // Clear the text fields
	                        TextID.setText("");
	                        textField_1.setText("");
	                        textField_2.setText("");
	                        textField_3.setText("");
	                        textField_4.setText("");
	                    }
	                }
	            }
	        });
		btnNewButton.setBounds(91, 284, 89, 23);
		contentPane.add(btnNewButton);
		
		btnNewButton_1 = new JButton("Save");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		        // Check if there are any duplicate entries in the table
		        boolean hasDuplicate = false;
		        for (int i = 0; i < tableModel.getRowCount(); i++) {
		            String orderID = tableModel.getValueAt(i, 0).toString();
		            if (isDuplicate(orderID)) {
		                hasDuplicate = true;
		                break;
		            }
		        }
		        String currentDirectory = System.getProperty("user.dir");
			    String filePath = currentDirectory + "/quotation.txt";
		        
		        if (hasDuplicate) {
		            // Display a warning message indicating that there are duplicate entries
		            JOptionPane.showMessageDialog(contentPane, "Duplicate entries found. Cannot save!", "Duplicate Entries", JOptionPane.WARNING_MESSAGE);
		        } else {
		            // Save the data to the file
		            try {
		                FileWriter writer = new FileWriter(filePath, true);
		                
		                for (int i = 0; i < tableModel.getRowCount(); i++) {
		                    String orderID = tableModel.getValueAt(i, 0).toString();
		                    String itemName = tableModel.getValueAt(i, 1).toString();
		                    String quantity = tableModel.getValueAt(i, 2).toString();
		                    String price = tableModel.getValueAt(i, 3).toString();
		                    String holdBy = tableModel.getValueAt(i, 4).toString();
		                    
		                    writer.write(orderID + "," + itemName + "," + quantity + "," + price + "," + holdBy + "\n");
		                }
		                
		                writer.close();
		                
		                JOptionPane.showMessageDialog(contentPane, "Data saved successfully!", "Save Successful", JOptionPane.INFORMATION_MESSAGE);
		            } catch (IOException ex) {
		                JOptionPane.showMessageDialog(contentPane, "Error saving data to file!", "Save Error", JOptionPane.ERROR_MESSAGE);
		            }
		        }
		    }
		});
		btnNewButton_1.setBounds(190, 284, 89, 23);
		contentPane.add(btnNewButton_1);
		
		lblNewLabel_5 = new JLabel("Search");
		lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_5.setBounds(249, 18, 58, 14);
		contentPane.add(lblNewLabel_5);
		
		textField_5 = new JTextField();
		textField_5.setBounds(317, 15, 353, 20);
		contentPane.add(textField_5);
		textField_5.setColumns(10);
		
		btnNewButton_2 = new JButton("Search ");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { String searchQuery = textField_5.getText().trim();
	        if (!searchQuery.isEmpty()) {
	            // Clear the table
	            tableModel.setRowCount(0);
	            
	            // Search for matching rows in the file
	            searchRowsInFile(searchQuery);
	        } else {
	            // If the search query is empty, display a warning message
	            JOptionPane.showMessageDialog(contentPane, "Please enter a search query.", "Empty Search Query", JOptionPane.WARNING_MESSAGE);
	        }
	    }
	});
		btnNewButton_2.setBounds(680, 14, 89, 23);
		contentPane.add(btnNewButton_2);
		
		btnNewButton_3 = new JButton("Delete");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		        int selectedRow = tablecontent.getSelectedRow();
		        if (selectedRow != -1) {
		            // Show a confirmation dialog before deleting the row
		            int confirm = JOptionPane.showConfirmDialog(contentPane, "Are you sure you want to delete this row?", "Delete Row", JOptionPane.YES_NO_OPTION);
		            if (confirm == JOptionPane.YES_OPTION) {
		                // Remove the selected row from the table model
		                tableModel.removeRow(selectedRow);
		                
		                // Clear the text fields
		                TextID.setText("");
		                textField_1.setText("");
		                textField_2.setText("");
		                textField_3.setText("");
		                textField_4.setText("");
		                
		                // Delete the row from the file
		                deleteRowFromFile(selectedRow);
		            }
		        } else {
		            // If no row is selected, display a warning message
		            JOptionPane.showMessageDialog(contentPane, "Please select a row to delete.", "No Row Selected", JOptionPane.WARNING_MESSAGE);
		        }
		    }
		});
		btnNewButton_3.setBounds(91, 331, 89, 23);
		contentPane.add(btnNewButton_3);
		
		tableModel = new DefaultTableModel(new Object[]{"OrderID", "Item Name", "Quantity", "Price", "Hold By"}, 0);
	    tablecontent = new JTable(tableModel);
	    tablecontent.setBounds(317, 46, 452, 554);
	    contentPane.add(tablecontent);
	    tablecontent.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
	        public void valueChanged(ListSelectionEvent event) {
	            if (!event.getValueIsAdjusting()) {
	                int selectedRow = tablecontent.getSelectedRow();
	                if (selectedRow != -1) {
	                    // Get the data from the selected row
	                    String orderID = tablecontent.getValueAt(selectedRow, 0).toString();
	                    String itemName = tablecontent.getValueAt(selectedRow, 1).toString();
	                    String quantity = tablecontent.getValueAt(selectedRow, 2).toString();
	                    String price = tablecontent.getValueAt(selectedRow, 3).toString();
	                    String holdBy = tablecontent.getValueAt(selectedRow, 4).toString();
	                    
	                    // Set the text fields with the selected row data
	                    TextID.setText(orderID);
	                    textField_1.setText(itemName);
	                    textField_2.setText(quantity);
	                    textField_3.setText(price);
	                    textField_4.setText(holdBy);
	                }
	            }
	        }
	    });
	  
	    // Create a JScrollPane and set the tablecontent as its viewport view
	    JScrollPane scrollPane = new JScrollPane(tablecontent);
	    scrollPane.setBounds(317, 46, 452, 554);
	    contentPane.add(scrollPane);
	    
	    JButton btnNewButton_4 = new JButton("Record");
	    btnNewButton_4.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {
	            if (tableModel.getRowCount() > 0) {
	                // Clear the table if it already has records
	                tableModel.setRowCount(0);
	            } else {
	                // Read the file records and display them in the table
	                try {
	                	String currentDirectory = System.getProperty("user.dir");
	             	    String filePath = currentDirectory + "/quotation.txt";
	                    BufferedReader reader = new BufferedReader(new FileReader(filePath));
	                    String line;
	                    while ((line = reader.readLine()) != null) {
	                        String[] data = line.split(",");
	                        if (data.length >= 5) {
	                            tableModel.addRow(new Object[]{data[0], data[1], data[2], data[3], data[4]});
	                        }
	                    }
	                    reader.close();
	                } catch (IOException ex) {
	                    ex.printStackTrace();
	                }
	            }
	        }
	    });
	    btnNewButton_4.setBounds(190, 331, 89, 23);
	    contentPane.add(btnNewButton_4);
	    
	    btnNewButton_5 = new JButton("Quit");
	    btnNewButton_5.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {
	    		SalePersonMain SalePersonMain = new SalePersonMain(username,"saleperson");
            	SalePersonMain.setVisible(true);
                dispose();
	    		
	    	}
	    });
	    btnNewButton_5.setBounds(0, 0, 89, 23);
	    contentPane.add(btnNewButton_5);
	    
		// Load the data from the file and populate the table
	    
	}

	private void deleteRowFromFile(int row) {
	    try {
	    	String currentDirectory = System.getProperty("user.dir");
	 	    String filename = currentDirectory + "/quotation.txt";
	        FileReader fileReader = new FileReader(filename);
	        BufferedReader bufferedReader = new BufferedReader(fileReader);
	        
	        StringBuilder sb = new StringBuilder();
	        String line;
	        int currentRow = 0;
	        while ((line = bufferedReader.readLine()) != null) {
	            if (currentRow != row) {
	                sb.append(line);
	                sb.append(System.lineSeparator());
	            }
	            currentRow++;
	        }
	        
	        bufferedReader.close();
	        fileReader.close();
	        
	        FileWriter fileWriter = new FileWriter(filename);
	        fileWriter.write(sb.toString());
	        fileWriter.close();
	        
	        System.out.println("Row deleted successfully from the file.");
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}
	private void searchRowsInFile(String searchQuery) {
	    try {
	    	String currentDirectory = System.getProperty("user.dir");
	 	    String filename = currentDirectory + "/quotation.txt";
	        FileReader fileReader = new FileReader(filename);
	        BufferedReader bufferedReader = new BufferedReader(fileReader);
	        
	        String line;
	        while ((line = bufferedReader.readLine()) != null) {
	            String[] row = line.split(",");
	            String itemName = row[1].trim();
	            String itemID = row[0].trim();
	            
	            // Check if the item name or item ID matches the search query
	            if (itemName.equalsIgnoreCase(searchQuery) || itemID.equalsIgnoreCase(searchQuery)) {
	                // Add the matching row to the beginning of the table model
	                tableModel.insertRow(0, row);
	            }
	        }
	        
	        bufferedReader.close();
	        fileReader.close();
	        
	        System.out.println("Search completed successfully.");
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}
	private boolean isDuplicate(String orderID) {
	    try {
	    	String currentDirectory = System.getProperty("user.dir");
	 	    String filePath = currentDirectory + "/quotation.txt";
	        BufferedReader reader = new BufferedReader(new FileReader(filePath));
	        String line;
	        while ((line = reader.readLine()) != null) {
	            String[] data = line.split(",");
	            if (data.length > 0 && data[0].equals(orderID)) {
	                reader.close();
	                return true;
	            }
	        }
	        reader.close();
	    } catch (IOException ex) {
	        ex.printStackTrace();
	    }
	    return false;
	}

}
