package Saleperson;

import java.awt.EventQueue;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class orderlistMain extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTable table;
    @SuppressWarnings("unused")
	private String username;
	private String officerUsername;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    orderlistMain frame = new orderlistMain("");
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public orderlistMain(String username) {
    	this.officerUsername = username;
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 675, 470);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        JLabel lblNewLabel = new JLabel("Order List");
        lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel.setBounds(201, 11, 238, 70);
        lblNewLabel.setFont(new Font("Imprint MT Shadow", Font.BOLD, 30));
        contentPane.add(lblNewLabel);
        
        JSeparator separator = new JSeparator();
        separator.setBounds(10, 60, 639, 2);
        contentPane.add(separator);
        
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(60, 73, 566, 347);
        contentPane.add(scrollPane);
        
        table = new JTable();
        scrollPane.setViewportView(table);
        
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("OrderID");
        model.addColumn("Item Name");
        model.addColumn("Quantity");
        model.addColumn("Price");
        model.addColumn("Status");
        model.addColumn("Time");
        table.setModel(model);
        
        // Read the quotation file and populate the table
        String currentDirectory = System.getProperty("user.dir");
        String filePath = currentDirectory + "/quotation.txt";
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                // Select columns 1-4 and 6-7
                String[] rowData = new String[]{data[0], data[1], data[2], data[3], data[5], data[6]};
                model.addRow(rowData);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        // Center align the table cells
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        table.setDefaultRenderer(Object.class, centerRenderer);
        
        // Set the header for the scroll pane
        JTableHeader header = table.getTableHeader();
        scrollPane.setColumnHeaderView(header);
        
        JButton btnNewButton = new JButton("Back");
        btnNewButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		SalePersonMain SalePersonMain = new SalePersonMain(officerUsername,"saleperson");
        		SalePersonMain.setVisible(true);
        		dispose();
        	}
        });
        btnNewButton.setBounds(537, 41, 89, 23);
        contentPane.add(btnNewButton);
    }
    
}