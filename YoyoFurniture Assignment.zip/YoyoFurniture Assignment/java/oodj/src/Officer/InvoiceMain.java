package Officer;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.text.Document;@SuppressWarnings("unused")


public class InvoiceMain extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField textField;
    private JTextField textField_1;
    private JTextField textField_2;
    private JTextField textField_3;
    private JTextField textField_4;
    private JTextField textField_5;
    private JTextField textField_6;
    private String username;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    InvoiceMain frame = new InvoiceMain("");
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public InvoiceMain(String username) {
    	this.username = username;
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 429, 442);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNewLabel = new JLabel("Invoice Printing System");
        lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel.setBounds(75, 11, 155, 27);
        contentPane.add(lblNewLabel);

        JLabel lblNewLabel_1 = new JLabel("Item Name");
        lblNewLabel_1.setBounds(10, 61, 71, 17);
        contentPane.add(lblNewLabel_1);

        textField = new JTextField();
        textField.setBounds(120, 59, 139, 20);
        contentPane.add(textField);
        textField.setColumns(10);

        textField_1 = new JTextField();
        textField_1.setBounds(120, 90, 139, 20);
        contentPane.add(textField_1);
        textField_1.setColumns(10);

        JLabel lblNewLabel_2 = new JLabel("Quantity");
        lblNewLabel_2.setBounds(10, 93, 64, 17);
        contentPane.add(lblNewLabel_2);

        textField_2 = new JTextField();
        textField_2.setBounds(120, 121, 139, 20);
        contentPane.add(textField_2);
        textField_2.setColumns(10);

        textField_3 = new JTextField();
        textField_3.setBounds(120, 152, 139, 20);
        contentPane.add(textField_3);
        textField_3.setColumns(10);

        textField_4 = new JTextField();
        textField_4.setBounds(120, 216, 139, 20);
        contentPane.add(textField_4);
        textField_4.setColumns(10);

        JButton btnNewButton = new JButton("Print Invoice");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String itemName = textField.getText();
                String quantity = textField_1.getText();
                String price = textField_2.getText();
                String subTotal = textField_3.getText();
                String tax = textField_4.getText();
                String total = textField_5.getText();
                String paymentMethod = textField_6.getText();

                // Print the invoice with the provided information
                printInvoice();
            }
        });
        btnNewButton.setBounds(170, 182, 139, 23);
        contentPane.add(btnNewButton);

        textField_5 = new JTextField();
        textField_5.setBounds(120, 247, 139, 20);
        contentPane.add(textField_5);
        textField_5.setColumns(10);

        textField_6 = new JTextField();
        textField_6.setBounds(120, 278, 139, 20);
        contentPane.add(textField_6);
        textField_6.setColumns(10);

        JLabel lblNewLabel_3 = new JLabel("Price");
        lblNewLabel_3.setBounds(10, 123, 46, 17);
        contentPane.add(lblNewLabel_3);

        JLabel lblNewLabel_4 = new JLabel("Sub Total");
        lblNewLabel_4.setBounds(10, 155, 64, 14);
        contentPane.add(lblNewLabel_4);

        JLabel lblNewLabel_5 = new JLabel("Tax");
        lblNewLabel_5.setBounds(10, 219, 46, 14);
        contentPane.add(lblNewLabel_5);

        JLabel lblNewLabel_6 = new JLabel("Total");
        lblNewLabel_6.setBounds(10, 250, 46, 14);
        contentPane.add(lblNewLabel_6);

        JLabel lblNewLabel_7 = new JLabel("Payment Method");
        lblNewLabel_7.setBounds(10, 281, 100, 14);
        contentPane.add(lblNewLabel_7);
        
        JButton btnNewButton_1 = new JButton("Done");
        btnNewButton_1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		officerMain officerMain = new officerMain(username);
        		officerMain.setVisible(true);
        		dispose();
        	}
        });
        btnNewButton_1.setBounds(170, 315, 139, 23);
        contentPane.add(btnNewButton_1);
    }
    private void printInvoice() {
        // Retrieve values from text fields
        String itemName = textField.getText().trim();
        String quantityStr = textField_1.getText().trim();
        String priceStr = textField_2.getText().trim();
        String subTotalStr = textField_3.getText().trim();
        String taxStr = textField_4.getText().trim();
        String totalStr = textField_5.getText().trim();
        String paymentMethod = textField_6.getText().trim();

        // Check if any field is empty
        if (itemName.isEmpty() || quantityStr.isEmpty() || priceStr.isEmpty() || subTotalStr.isEmpty()
                || taxStr.isEmpty() || totalStr.isEmpty() || paymentMethod.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Parse numerical values
        int quantity;
        double price, subTotal, tax, total;
        try {
            quantity = Integer.parseInt(quantityStr);
            price = Double.parseDouble(priceStr);
            subTotal = Double.parseDouble(subTotalStr);
            tax = Double.parseDouble(taxStr);
            total = Double.parseDouble(totalStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter valid numerical values!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Define the printer job
        PrinterJob job = PrinterJob.getPrinterJob();
        job.setPrintable(new Printable() {
            @Override
            public int print(Graphics graphics, PageFormat pageFormat, int pageIndex) throws PrinterException {
                if (pageIndex > 0) {
                    return Printable.NO_SUCH_PAGE;
                }

                Graphics2D g2d = (Graphics2D) graphics;
                g2d.translate(pageFormat.getImageableX(), pageFormat.getImageableY());

                // Set up fonts
                Font titleFont = new Font("Arial", Font.BOLD, 20);
                Font regularFont = new Font("Arial", Font.PLAIN, 12);

                // Draw a box around the entire invoice
                g2d.drawRect(50, 50, 300, 250);

                // Draw title
                g2d.setFont(titleFont);
                g2d.drawString("Invoice", 150, 70);

                // Draw details
                int x = 60;
                int y = 90;
                int lineHeight = 20;
                g2d.setFont(regularFont);
                g2d.drawString("Item Name: " + itemName, x, y);
                g2d.drawString("Quantity: " + quantity, x, y + lineHeight);
                g2d.drawString("Price: RM" + String.format("%.2f", price), x, y + 2 * lineHeight);
                g2d.drawString("Sub Total: RM" + String.format("%.2f", subTotal), x, y + 3 * lineHeight);
                g2d.drawString("Tax: RM" + String.format("%.2f", tax), x, y + 4 * lineHeight);
                g2d.drawString("Total: RM" + String.format("%.2f", total), x, y + 5 * lineHeight);
                g2d.drawString("Payment Method: " + paymentMethod, x, y + 6 * lineHeight);

                return Printable.PAGE_EXISTS;
            }
        });

        // Show print dialog and print
        if (job.printDialog()) {
            try {
                job.print();
            } catch (PrinterException ex) {
                ex.printStackTrace();
            }
        }
    }
}
   