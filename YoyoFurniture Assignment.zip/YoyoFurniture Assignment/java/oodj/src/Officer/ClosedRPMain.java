package Officer;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;

import javax.swing.table.DefaultTableModel;

import Admin.GenerateReportMain;

import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;


import javax.swing.JTable;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ClosedRPMain extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;
	@SuppressWarnings("unused")
	private String username;
	private String userRole;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ClosedRPMain frame = new ClosedRPMain("");
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ClosedRPMain(String username) {
		this.username = username;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 666, 365);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Closed Sale Order");
		lblNewLabel.setFont(new Font("Imprint MT Shadow", Font.BOLD, 30));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(186, 11, 269, 46);
		contentPane.add(lblNewLabel);

		table = new JTable();
		DefaultTableModel model = new DefaultTableModel();
		model.addColumn("OrderID");
		model.addColumn("Item Name");
		model.addColumn("Quantity");
		model.addColumn("Price");
		model.addColumn("Sign By");
		model.addColumn("Status");
		model.addColumn("Progress");
		table.setModel(model);

		 String currentDirectory = System.getProperty("user.dir");
		 String filePath = currentDirectory + "/quotation.txt";
		try {
		    BufferedReader reader = new BufferedReader(new FileReader(filePath));
		    String line;
		    while ((line = reader.readLine()) != null) {
		        String[] data = line.split(",");
		        if (data.length >= 7 && data[6].equals("Closed")) {
		            model.addRow(data);
		        }
		    }
		    reader.close();
		} catch (IOException e) {
		    e.printStackTrace();
		}

		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setBounds(10, 68, 630, 181);
		contentPane.add(scrollPane);
		
		JButton btnNewButton = new JButton("Back");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GenerateReportMain GenerateReportMain = new GenerateReportMain(username,userRole,"");
				GenerateReportMain.setVisible(true);
				dispose();
			
			}
		});
		btnNewButton.setBounds(551, 11, 89, 23);
		contentPane.add(btnNewButton);



   }
}
