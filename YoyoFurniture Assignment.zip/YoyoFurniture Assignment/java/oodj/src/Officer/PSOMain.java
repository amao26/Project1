package Officer;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import java.awt.Font;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.SwingConstants;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JSeparator;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class PSOMain extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private final JLabel lblNewLabel = new JLabel("Process and Sale Order");
	private JTable table;
	private JTextField textField;
	@SuppressWarnings("unused")
	private String username;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PSOMain frame = new PSOMain("");
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @param username 
	 */
	public PSOMain(String username) {
		this.username = username;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 910, 488);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Imprint MT Shadow", Font.BOLD, 30));
		lblNewLabel.setBounds(10, 0, 390, 65);
		contentPane.add(lblNewLabel);
		
		table = new JTable();
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(10, 102, 874, 336);
        contentPane.add(scrollPane);
		
		JLabel lblNewLabel_1 = new JLabel("Search");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(191, 65, 80, 26);
		contentPane.add(lblNewLabel_1);
		
		textField = new JTextField();
		textField.setBounds(281, 70, 246, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(10, 46, 874, 2);
		contentPane.add(separator);
		
		JButton btnNewButton = new JButton("Search");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String searchKeyword = textField.getText();
                searchOrders(searchKeyword);
				
			}
		});
		btnNewButton.setBounds(537, 69, 89, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Modify");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int selectedRow = table.getSelectedRow();
		        int selectedColumn = table.getSelectedColumn();
		        String newValue = (String) table.getValueAt(selectedRow, selectedColumn);

		        if (selectedRow != -1 && selectedColumn != -1) {
		            DefaultTableModel model = (DefaultTableModel) table.getModel();
		            model.setValueAt(newValue, selectedRow, selectedColumn);

		            // Save the modified data back to the file
		            saveToFile(selectedRow, selectedColumn);
		        }
		    }
		});
		btnNewButton_1.setBounds(692, 69, 89, 23);
		contentPane.add(btnNewButton_1);
	
		DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Order ID");
        model.addColumn("Item Name");
        model.addColumn("Quantity");
        model.addColumn("Price");
        model.addColumn("Sign By");
        model.addColumn("Status");
        model.addColumn("Progress");
        model.addColumn("DateTime");
        table.setModel(model);
        
        JButton btnNewButton_2 = new JButton("Quit");
        btnNewButton_2.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		officerMain officerMain = new officerMain(username);
        		officerMain.setVisible(true);
        		dispose();
        	}
        });
        btnNewButton_2.setBounds(795, 27, 89, 23);
        contentPane.add(btnNewButton_2);

        String currentDirectory = System.getProperty("user.dir");
	    String filePath = currentDirectory + "/quotation.txt";
    try {
        BufferedReader reader = new BufferedReader(new FileReader(filePath));
        String line;
        while ((line = reader.readLine()) != null) {
            String[] data = line.split(",");
            model.addRow(data);
        }
        reader.close();
    } catch (IOException e) {
        e.printStackTrace();
       }
    
	}
        
    private void searchOrders(String keyword) {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        model.setRowCount(0); // Clear previous search results

        String currentDirectory = System.getProperty("user.dir");
	    String filePath = currentDirectory + "/quotation.txt";
        try {
            BufferedReader reader = new BufferedReader(new FileReader(filePath));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                if (data[0].contains(keyword) || data[1].contains(keyword)) {
                    model.addRow(data);
                }
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
      }
    private void saveToFile(int modifiedRow, int modifiedColumn) {
        String currentDirectory = System.getProperty("user.dir");
        String filePath = currentDirectory + "/quotation.txt";

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            StringBuilder fileContent = new StringBuilder();
            String line;
            int currentRow = 0;

            while ((line = reader.readLine()) != null) {
                if (currentRow == modifiedRow) {
                    // Split the line into individual data elements
                    String[] data = line.split(",");
                    // Ensure the array has enough elements to update
                    if (data.length > modifiedColumn) {
                        // Update the modified value in the current row
                        data[modifiedColumn] = table.getValueAt(modifiedRow, modifiedColumn).toString();
                        // Join the modified data back into a single line
                        line = String.join(",", data);
                    } else {
                        // If the column index is out of bounds, append an empty string
                        while (data.length <= modifiedColumn) {
                            line += ",";
                            data = line.split(",");
                        }
                        data[modifiedColumn] = table.getValueAt(modifiedRow, modifiedColumn).toString();
                        line = String.join(",", data);
                    }
                }
                fileContent.append(line).append("\n");
                currentRow++;
            }

            // Write the updated content back to the file
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
                writer.write(fileContent.toString());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}