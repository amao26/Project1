package Officer;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

import Admin.GenerateReportMain;

import javax.swing.JLabel;
import java.awt.Font;
import java.awt.GridLayout;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.SwingConstants;
import javax.swing.JSeparator;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class WorkDoneRPMain extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;
	@SuppressWarnings("unused")
	private String username;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					WorkDoneRPMain frame = new WorkDoneRPMain("");
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public WorkDoneRPMain(String username) {
		this.username = username;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 687, 463);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Work Done Report");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Imprint MT Shadow", Font.BOLD, 30));
		lblNewLabel.setBounds(-14, 0, 342, 49);
		contentPane.add(lblNewLabel);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(24, 40, 543, 2);
		contentPane.add(separator);
		
		JButton btnNewButton = new JButton("Back");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GenerateReportMain GenerateReportMain = new GenerateReportMain(username,"","");
        		GenerateReportMain.setVisible(true);
        		dispose();
			}
			
		});
		btnNewButton.setBounds(572, 19, 89, 23);
		contentPane.add(btnNewButton);
		
		table = new JTable();
		table.setBounds(88, 60, 536, 324);

		DefaultTableModel model = new DefaultTableModel();
		model.addColumn("OrderID");
		model.addColumn("Item Name");
		model.addColumn("Price");
		model.addColumn("Sign By");
		model.addColumn("Approve Time");
		table.setModel(model);

		 String currentDirectory = System.getProperty("user.dir");
		    String filePath = currentDirectory + "/quotation.txt";
		try {
		    BufferedReader reader = new BufferedReader(new FileReader(filePath));
		    String line;
		    while ((line = reader.readLine()) != null) {
		        String[] data = line.split(",");
		        if (data.length >= 8) {
		            String orderID = data[0];
		            String itemName = data[1];
		            String price = data[3];
		            String signBy = data[4];
		            String approveTime = data[7]; // Index of the "Approve Time" column
		            model.addRow(new Object[]{orderID, itemName, price, signBy, approveTime});
		        }
		    }
		    reader.close();
		} catch (IOException e) {
		    e.printStackTrace();
		}

		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setBounds(88, 60, 536, 324);
		contentPane.add(scrollPane);

		table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
		    public void valueChanged(ListSelectionEvent event) {
		        int selectedRow = table.getSelectedRow();
		        if (selectedRow != -1) {
		            String orderID = (String) table.getValueAt(selectedRow, 0); // Index of the "OrderID" column
		            String itemName = (String) table.getValueAt(selectedRow, 1); // Index of the "Item Name" column
		            String price = (String) table.getValueAt(selectedRow, 2); // Index of the "Price" column
		            String signBy = (String) table.getValueAt(selectedRow, 3); // Index of the "Sign By" column
		            String approveTime = (String) table.getValueAt(selectedRow, 4); // Index of the "Approve Time" column

		            JFrame summaryFrame = new JFrame();
		            summaryFrame.setBounds(200, 200, 400, 200);
		            summaryFrame.setTitle("Work Done Report");
		            summaryFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		            
		            JPanel summaryPanel = new JPanel();
		            summaryPanel.setLayout(new GridLayout(5, 2));
		            summaryPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Add padding
		            
		            Font labelFont = new Font("Arial", Font.BOLD, 12); // Customize font for labels
		            Font valueFont = new Font("Arial", Font.PLAIN, 12); // Customize font for values
		            
		            JLabel orderLabel = new JLabel("Order ID:");
		            orderLabel.setFont(labelFont);
		            summaryPanel.add(orderLabel);
		            
		            JLabel orderValue = new JLabel(orderID);
		            orderValue.setFont(valueFont);
		            summaryPanel.add(orderValue);
		            
		            JLabel itemNameLabel = new JLabel("Item Name:");
		            itemNameLabel.setFont(labelFont);
		            summaryPanel.add(itemNameLabel);
		            
		            JLabel itemNameValue = new JLabel(itemName);
		            itemNameValue.setFont(valueFont);
		            summaryPanel.add(itemNameValue);
		            
		            JLabel priceLabel = new JLabel("Price:");
		            priceLabel.setFont(labelFont);
		            summaryPanel.add(priceLabel);
		            
		            JLabel priceValue = new JLabel(price);
		            priceValue.setFont(valueFont);
		            summaryPanel.add(priceValue);
		            
		            JLabel signByLabel = new JLabel("Sign By:");
		            signByLabel.setFont(labelFont);
		            summaryPanel.add(signByLabel);
		            
		            JLabel signByValue = new JLabel(signBy);
		            signByValue.setFont(valueFont);
		            summaryPanel.add(signByValue);
		            
		            JLabel approveTimeLabel = new JLabel("Approve Time:");
		            approveTimeLabel.setFont(labelFont);
		            summaryPanel.add(approveTimeLabel);
		            
		            JLabel approveTimeValue = new JLabel(approveTime);
		            approveTimeValue.setFont(valueFont);
		            summaryPanel.add(approveTimeValue);
		            
		            summaryFrame.getContentPane().add(summaryPanel);
		            summaryFrame.setVisible(true);
		        }
		    }
		});
	}

}
