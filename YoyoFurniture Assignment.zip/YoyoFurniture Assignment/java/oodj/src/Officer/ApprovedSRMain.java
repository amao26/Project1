package Officer;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import Admin.GenerateReportMain;

import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.awt.event.ActionEvent;


public class ApprovedSRMain extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable statustable;
	@SuppressWarnings("unused")
	private String username;
	private String userRole;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					String username = "john123";
					ApprovedSRMain frame = new ApprovedSRMain(username);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @param userRole 
	 */
	public ApprovedSRMain(String username) {
		this.username = username;
		 System.out.println("Username received in ApprovedSRMain: " + username); // Print out the received username
	
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    setBounds(100, 100, 850, 394);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Approval Sale Order");
		lblNewLabel.setFont(new Font("Imprint MT Shadow", Font.BOLD, 30));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(10, 11, 306, 64);
		contentPane.add(lblNewLabel);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(10, 62, 306, 2);
		contentPane.add(separator);
		
		JButton btnNewButton = new JButton("Approved");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		        int selectedRow = statustable.getSelectedRow();
		        if (selectedRow != -1) {
		            // Update the status column of the selected row to "Approve"
		            statustable.setValueAt("Approve", selectedRow, 5);
		            saveTimeToFile(selectedRow + 1);
		            
		            saveDataToFile();
		        }
		    }
		});
		btnNewButton.setBounds(47, 115, 110, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("UnApproved");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		        int selectedRow = statustable.getSelectedRow();
		        if (selectedRow != -1) {
		            // Update the status column of the selected row to "Approve"
		            statustable.setValueAt("UnApproved", selectedRow, 5);
		            saveTimeToFile(selectedRow + 1);
		            
		            saveDataToFile();
		        }
		    }
		});		btnNewButton_1.setBounds(47, 156, 110, 23);
		contentPane.add(btnNewButton_1);
		
		statustable = new JTable();
        JScrollPane scrollPane = new JScrollPane(statustable);
        scrollPane.setBounds(223, 78, 601, 204);
        contentPane.add(scrollPane);

        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("OrderID");
        model.addColumn("Item Name");
        model.addColumn("Quantity");
        model.addColumn("Price");
        model.addColumn("Sign By");
        model.addColumn("Status");
        model.addColumn("Progress");
        statustable.setModel(model);
        
        JButton btnNewButton_2 = new JButton("Back");
        btnNewButton_2.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		GenerateReportMain GenerateReportMain = new GenerateReportMain(username,"",userRole);
        		GenerateReportMain.setVisible(true);
        		dispose();
  
        	}
        });
        btnNewButton_2.setBounds(726, 11, 98, 26);
        contentPane.add(btnNewButton_2);
        
        JButton btnNewButton_3 = new JButton("Closed");
        btnNewButton_3.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
                int selectedRow = statustable.getSelectedRow();
                int selectedColumn = 6; // Index of the "Progress" column
                if (selectedRow != -1) {
                    String currentValue = (String) statustable.getValueAt(selectedRow, selectedColumn);
                    if (currentValue == null) {
                        // Update the progress column of the selected row to "On Progress"
                        statustable.setValueAt("On Progress", selectedRow, selectedColumn);
                    } else if (currentValue.equals("Closed")) {
                        // Update the progress column of the selected row to "On Progress"
                        statustable.setValueAt("On Progress", selectedRow, selectedColumn);
                    } else {
                        // Update the progress column of the selected row to "Closed"
                        statustable.setValueAt("Closed", selectedRow, selectedColumn);
                    }
                    saveDataToFile();
                }
            }
        });
        btnNewButton_3.setBounds(47, 190, 110, 23);
        contentPane.add(btnNewButton_3);

        String currentDirectory = System.getProperty("user.dir");
		String filePath = currentDirectory + "/quotation.txt";
        try {
            BufferedReader reader = new BufferedReader(new FileReader(filePath));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                model.addRow(data);
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
	private void saveDataToFile() {
		String currentDirectory = System.getProperty("user.dir");
		String filePath = currentDirectory + "/quotation.txt";
	    try {
	        BufferedWriter writer = new BufferedWriter(new FileWriter(filePath));
	        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
	        for (int row = 0; row < statustable.getRowCount(); row++) {
	            for (int col = 0; col < statustable.getColumnCount(); col++) {
	                Object cellValue = statustable.getValueAt(row, col);
	                if (cellValue != null) {
	                    writer.write(cellValue.toString());
	                }
	                if (col < statustable.getColumnCount() - 1) {
	                    writer.write(",");
	                }
	            }
	            // Save the progress time to the following row file
	            if (statustable.getValueAt(row, 6).equals("Closed")) {
	                LocalDateTime currentTime = LocalDateTime.now();
	                String formattedTime = currentTime.format(formatter);
	                writer.write("," + formattedTime);
	            } else {
	                // Save the time for approved rows
	                if (statustable.getValueAt(row, 5).equals("Approve")) {
	                    LocalDateTime currentTime = LocalDateTime.now();
	                    String formattedTime = currentTime.format(formatter);
	                    writer.write("," + formattedTime);
	                }
	                writer.write(","); // Add an empty column for rows without "Closed" progress
	            }
	            writer.newLine();
	        }
	        writer.close();
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}

	private void saveTimeToFile(int row) {
		String currentDirectory = System.getProperty("user.dir");
		String filePath = currentDirectory + "/time.txt";
	    try {
	        BufferedWriter writer = new BufferedWriter(new FileWriter(filePath, true));
	        LocalDateTime currentTime = LocalDateTime.now();
	        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
	        String formattedTime = currentTime.format(formatter);
	        writer.write("Row " + row + ": " + formattedTime);
	        writer.newLine();
	        writer.close();
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}
}
