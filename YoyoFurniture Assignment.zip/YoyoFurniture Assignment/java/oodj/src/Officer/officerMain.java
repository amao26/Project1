	package Officer;
	
	import java.awt.EventQueue;

import javax.swing.JFrame;
	import javax.swing.JPanel;
	import javax.swing.border.EmptyBorder;

import Admin.GenerateReportMain;
import Admin.ProfileManagement;
import Login.LoginScreen;
import Officer.UserProfileManager;

import javax.swing.JLabel;
	import javax.swing.SwingConstants;
	import java.awt.Font;
	import javax.swing.JButton;
	import java.awt.event.ActionListener;
	import java.awt.event.ActionEvent;
	import javax.swing.JSeparator;
	
	
	@SuppressWarnings("unused")
	public class officerMain extends JFrame {
	
		private static final long serialVersionUID = 1L;
		private JPanel contentPane;
		private String officerUsername;
		private JLabel usernameLabel;
		@SuppressWarnings("unused")
		private String userRole;
		private String username;
		private ProfileManagement profileManagement;
		
		
		public static void main(String[] args) {
			EventQueue.invokeLater(new Runnable() {
				public void run() {
					try {
						officerMain frame = new officerMain("");
						frame.setVisible(true);
					} catch (Exception e) {
						e.printStackTrace();
	  			 }
				}
			});
		}
	
		/**
		 * Create the frame.
		 */
		public officerMain(String username) {
			this.username = username; // Save the login username
			this.userRole = "officer";
			this.officerUsername = username;
			 profileManagement = new ProfileManagement("","");
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			setBounds(100, 100, 675, 470);
			contentPane = new JPanel();
			contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
	
			setContentPane(contentPane);
			contentPane.setLayout(null);
			
			JLabel lblNewLabel = new JLabel("Officer Page");
			lblNewLabel.setFont(new Font("Imprint MT Shadow", Font.BOLD, 30));
			lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel.setBounds(85, 46, 206, 63);
			contentPane.add(lblNewLabel);
			
			JButton btnNewButton = new JButton("Log Out");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					LoginScreen loginScreen = new LoginScreen();
					loginScreen.setVisible(true);
					dispose();
				}
			});
			btnNewButton.setBounds(479, 72, 89, 23);
			contentPane.add(btnNewButton);
			
			JSeparator separator = new JSeparator();
			separator.setBounds(102, 93, 474, 2);
			contentPane.add(separator);
			
			JButton btnNewButton_1 = new JButton("Product Status");
			btnNewButton_1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					ProductStatusMain ProductStatusMain = new ProductStatusMain(username);
					ProductStatusMain.setVisible(true);
					dispose();				
				}
			});
			btnNewButton_1.setBounds(64, 197, 130, 55);
			contentPane.add(btnNewButton_1);
			
			JButton btnNewButton_2 = new JButton("Sale Order Process");
			btnNewButton_2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					PSOMain PSOMain = new PSOMain(username);
					PSOMain.setVisible(true);
					dispose();
				}
			});
			btnNewButton_2.setBounds(188, 197, 158, 55);
			contentPane.add(btnNewButton_2);
			
			
			JButton btnNewButton_3 = new JButton("Generate Invoice");
			btnNewButton_3.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					InvoiceMain InvoiceMain = new  InvoiceMain(username);
					InvoiceMain.setVisible(true);
					dispose();
					
					}
			});
			btnNewButton_3.setBounds(347, 197, 130, 55);
			contentPane.add(btnNewButton_3);
			
			JSeparator separator_1 = new JSeparator();
			separator_1.setBounds(94, 195, 496, 0);
			contentPane.add(separator_1);
			
			JButton btnNewButton_4 = new JButton("Generate Report");
			btnNewButton_4.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					GenerateReportMain GenerateReportMain = new GenerateReportMain(username,"officer","");
					GenerateReportMain.setVisible(true);
					dispose();
					
					}
			});
			btnNewButton_4.setBounds(479, 197, 130, 55);
			contentPane.add(btnNewButton_4);
			
			JButton btnNewButton_5 = new JButton("Manage Profile");
			btnNewButton_5.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {	
					ProfileManagement PM1 = new ProfileManagement(username, "officer");
			        PM1.setVisible(true);
			        dispose();
			        
				}
	
		});
			btnNewButton_5.setBounds(104, 104, 123, 23);
			contentPane.add(btnNewButton_5);
			
			usernameLabel = new JLabel();
	        usernameLabel.setHorizontalAlignment(SwingConstants.CENTER);
			usernameLabel.setBounds(350, 72, 140, 23);
			contentPane.add(usernameLabel);
			
			JLabel lblNewLabel_1 = new JLabel("Welcome User");
			lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel_1.setBounds(283, 76, 95, 14);
			contentPane.add(lblNewLabel_1);
			
			retrieveUserProfile();
			
		}
		
	
		
		    
		void retrieveUserProfile() {
		    UserProfileManager userProfileManager = new UserProfileManager(username,usernameLabel);
		    userProfileManager.retrieveUserProfile();
		}		
	}
