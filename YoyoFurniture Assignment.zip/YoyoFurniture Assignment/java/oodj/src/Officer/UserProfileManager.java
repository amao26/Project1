package Officer;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import javax.swing.JLabel;

@SuppressWarnings("unused")
public class UserProfileManager {
    private String username;
    private JLabel usernameLabel;
	private String officerUsername;

    public UserProfileManager(String username, JLabel usernameLabel) {
        this.username = username;
        this.usernameLabel = usernameLabel;
    }

    public void retrieveUserProfile() {
        try {
            String currentDirectory = System.getProperty("user.dir");
            String filePath = currentDirectory + "/users.txt";
            
            BufferedReader reader = new BufferedReader(new FileReader(filePath));
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.contains("Username: " + username)) {
                    String[] userInfo = line.split("\\|");
                    for (String info : userInfo) {
                        if (info.contains("Username: ")) {
                            String username = info.trim().replace("Username: ", "");
                            usernameLabel.setText(username);
                            System.out.println("Username found: " + username);
                        }
                        // Add code to handle other user information fields
                    }
                    break;
                }
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
            // Handle file IO errors
        } catch (Exception e) {
            e.printStackTrace();
            // Handle other exceptions
        }
    }

}
